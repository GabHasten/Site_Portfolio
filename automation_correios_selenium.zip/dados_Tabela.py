import pandas as pd

def carregar_dados():

    url = "https://docs.google.com/spreadsheets/d/1CArD1Jow6kMaory575m3aNjAc1XYJi2a8vKcevwWQWc/export?format=csv"
    df = pd.read_csv(url)

    etiquetas = []

    for _, row in df.iterrows():
        etiquetas.append({
            # DESTINATÁRIO
            "DES_CEP": row["CEP"],
            "DES_NOME": row["NOME"],
            "DES_ENDERECO": row["ENDERECO"],
            "DES_NUMERO": row["NUMERO"],
            "DES_COMPLEMENTO": row["COMPLEMENTO"],
            "DES_BAIRRO": row["BAIRRO"],
            "DES_CIDADE": row["CIDADE"],

            # DECLARAÇÃO DE CONTEÚDO
            "CPF_CNPJ": row["CPF_CNPJ"],
            "CONTEUDO": row["CONTEUDO"],
            "QTD": row["QTD"],
            "VALOR": row["VALOR"],
            "PESO": row["PESO"],
        })

    return etiquetas