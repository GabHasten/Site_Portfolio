import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from dados_Tabela import carregar_dados

# =========================================================
# CONFIGURAÇÕES DE DADOS FIXOS (REMETENTE)
# =========================================================
# Estas variáveis definem as informações de quem está enviando.
# Em versões futuras, esses campos podem ser integrados a uma API.
# =========================================================

CEP = "22241-125"
ENDERECO = "Parque Nacional da Tijuca"
NUMERO = "S/N"
NOME = "Cristo Redentor"
COMPLEMENTO = "Corcovado"
BAIRRO = "Alto da Boa Vista"
CIDADE = "Rio de Janeiro"
CNPJ = "11.111.111/0001-11"
# =========================================================

# VALIDAÇÃO DE ENTRADA DO USUÁRIO
# =========================================================
# Loop para garantir que a quantidade de etiquetas seja válida.
# O site dos Correios permite o preenchimento de até 4 etiquetas por vez.
# =========================================================
while True:
    try:
        quantidade_input = input("Quantas etiquetas deseja preencher (1 a 4)? ")
        valorEtiquetas = int(quantidade_input)
        
        if 1 <= valorEtiquetas <= 4:
            break # Sai do loop se o valor for válido
        else:
            print("Por favor, digite um número entre 1 e 4.")
    except ValueError:
        print("Entrada inválida! Digite apenas números inteiros.")

# =========================================================
# INICIALIZAÇÃO DO NAVEGADOR
# =========================================================
# Configura o WebDriver do Selenium para abrir o site oficial.
# =========================================================
driver = webdriver.Chrome()
driver.get("https://www2.correios.com.br/enderecador/encomendas/default.cfm?etq=1&tipo=rem#form1")
driver.maximize_window()

# Pausa para garantir o carregamento do DOM antes da interação
time.sleep(3)

# =========================================================
# FUNÇÃO: prenchimento (REMETENTE)
# =========================================================
# Preenche os dados de quem envia nos campos 'cep_i', 'nome_i', etc.
# i representa o índice da etiqueta na página.
# =========================================================
def prenchimento(valorEtiquetas):

    # Função utilitária para fechar anúncios/pop-ups intrusivos do site
    def bt_fechar():
        try:
            bt_x = driver.find_element(
                By.XPATH,
                "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[3]/div/span"
            )
            bt_x.click()
        except:
            pass # Prossegue se o botão não for encontrado

    bt_fechar()

    # Itera de 1 até a quantidade definida pelo usuário
    for i in range(1, valorEtiquetas + 1):
        # Limpa e preenche o CEP
        driver.find_element(By.ID, f"cep_{i}").clear()
        driver.find_element(By.ID, f"cep_{i}").send_keys(CEP)
        
        # O clique no endereço ativa a validação automática do CEP no site
        driver.find_element(By.ID, f"endereco_{i}").click()
        time.sleep(2) # Aguarda a resposta do servidor de CEP

        bt_fechar()

        # Preenchimento dos demais campos do formulário de remetente
        driver.find_element(By.ID, f"nome_{i}").clear()
        driver.find_element(By.ID, f"nome_{i}").send_keys(NOME)

        driver.find_element(By.ID, f"endereco_{i}").clear()
        driver.find_element(By.ID, f"endereco_{i}").send_keys(ENDERECO)

        driver.find_element(By.ID, f"numero_{i}").clear()
        driver.find_element(By.ID, f"numero_{i}").send_keys(NUMERO)

        driver.find_element(By.ID, f"complemento_{i}").clear()
        driver.find_element(By.ID, f"complemento_{i}").send_keys(COMPLEMENTO)

        driver.find_element(By.ID, f"bairro_{i}").clear()
        driver.find_element(By.ID, f"bairro_{i}").send_keys(BAIRRO)

        driver.find_element(By.ID, f"cidade_{i}").clear()
        driver.find_element(By.ID, f"cidade_{i}").send_keys(CIDADE)

# =========================================================
# FUNÇÃO: preencher_despachante (DESTINATÁRIO)
# =========================================================
# Lê os dados da planilha/tabela e preenche as informações de destino.
# =========================================================
def preencher_despachante(valorEtiquetas):
    # Carrega a lista de destinatários do arquivo externo
    etiquetas = carregar_dados()

    def bt_fechar():
        try:
            bt_x = driver.find_element(By.XPATH, "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[3]/div/span")
            bt_x.click()
        except:
            pass

# Processa as etiquetas em blocos conforme a quantidade escolhida
    for i in range(0, len(etiquetas), valorEtiquetas):
        bloco = etiquetas[i:i+valorEtiquetas]
        bt_fechar()

        # Enumera o bloco para encontrar os IDs 'desCep_1', 'desCep_2', etc.
        for idx, dados in enumerate(bloco, start=1):
            # aqui você pode acessar cada etiqueta do bloco
            # exemplo: print(f"Etiqueta {idx}: {dados}")

            driver.find_element(By.ID, f"desCep_{idx}").clear()
            driver.find_element(By.ID, f"desCep_{idx}").send_keys(dados["DES_CEP"])

            driver.find_element(By.ID, f"desEndereco_{idx}").click()
            time.sleep(2)
            bt_fechar()

            driver.find_element(By.ID, f"desNome_{idx}").clear()
            driver.find_element(By.ID, f"desNome_{idx}").send_keys(dados["DES_NOME"])

            driver.find_element(By.ID, f"desEndereco_{idx}").clear()
            driver.find_element(By.ID, f"desEndereco_{idx}").send_keys(dados["DES_ENDERECO"])

            driver.find_element(By.ID, f"desNumero_{idx}").clear()
            driver.find_element(By.ID, f"desNumero_{idx}").send_keys(dados["DES_NUMERO"])

            driver.find_element(By.ID, f"desComplemento_{idx}").clear()
            driver.find_element(By.ID, f"desComplemento_{idx}").send_keys(dados["DES_COMPLEMENTO"])

            driver.find_element(By.ID, f"desBairro_{idx}").clear()
            driver.find_element(By.ID, f"desBairro_{idx}").send_keys(dados["DES_BAIRRO"])

            driver.find_element(By.ID, f"desCidade_{idx}").clear()
            driver.find_element(By.ID, f"desCidade_{idx}").send_keys(dados["DES_CIDADE"])

        time.sleep(5)

# =========================================================
# FUNÇÃO: abrir_e_tratar_declaracao
# =========================================================
# Lida com a abertura de uma nova aba para a declaração de conteúdo.
# =========================================================
def abrir_e_tratar_declaracao(xpath_botao, dados):
    # Salva a referência da aba principal (lista de etiquetas)
    aba_principal = driver.current_window_handle

    # Abre o pop-up da declaração
    driver.find_element(By.XPATH, xpath_botao).click()
    time.sleep(2)

    # Muda o foco para a aba recém-aberta
    driver.switch_to.window(driver.window_handles[-1])

    # Preenche os dados obrigatórios do conteúdo
    driver.find_element(By.ID, "desCnpjcpf").clear()
    driver.find_element(By.ID, "desCnpjcpf").send_keys(dados["CPF_CNPJ"])

    driver.find_element(By.ID, "cont1").clear()
    driver.find_element(By.ID, "cont1").send_keys(dados["CONTEUDO"])

    driver.find_element(By.ID, "quant1").clear()
    driver.find_element(By.ID, "quant1").send_keys(dados["QTD"])

    driver.find_element(By.ID, "val1").clear()
    driver.find_element(By.ID, "val1").send_keys(dados["VALOR"])

    driver.find_element(By.ID, "pesototal").clear()
    driver.find_element(By.ID, "pesototal").send_keys(dados["PESO"])

    time.sleep(2)

    # Botão "Imprimir" (que na verdade salva os dados no sistema do site)
    driver.find_element(By.XPATH, "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[2]/table[4]/tbody/tr/td[1]/a/font").click()

    time.sleep(1)
    # Fecha a aba da declaração e retorna para a lista de etiquetas
    driver.close()
    driver.switch_to.window(aba_principal)

# =========================================================
# FUNÇÃO: preencher_conteudo
# =========================================================
# Gerencia a ordem de abertura das declarações conforme a quantidade.
# =========================================================
def preencher_conteudo():
    etiquetas = carregar_dados()
    
    # Mapeamento dos botões de declaração na página (1 a 4)
    xpaths = [
        "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[2]/form/div[3]/div/span[9]/label/li/a",
        "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[2]/form/div[5]/div/span[9]/label/li/a",
        "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[2]/form/div[7]/div/span[9]/label/li/a",
        "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[2]/form/div[9]/div/span[9]/label/li/a",
    ]

    # Preenche apenas as declarações das etiquetas selecionadas
    for xpath, dados in zip(xpaths, etiquetas[:valorEtiquetas]):
        abrir_e_tratar_declaracao(xpath, dados)

# =========================================================
# BLOCO PRINCIPAL DE EXECUÇÃO
# =========================================================
try:
    carregar_dados()
    prenchimento(valorEtiquetas)      # Preenche Remetente
    preencher_despachante(valorEtiquetas) # Preenche Destinatário
    preencher_conteudo()               # Preenche Declarações
    
    # Gera o PDF final com todas as etiquetas
    driver.find_element(By.ID,"btGerarEtiquetas").click()
    
    # Tempo longo para permitir o download ou visualização do arquivo
    time.sleep(160)
    print("O código rodou por completo!")

except Exception as e:
    # Captura erros inesperados para não fechar o console imediatamente
    print(f"Erro ocorrido: {e}")