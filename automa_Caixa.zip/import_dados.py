import pandas as pd

def import_lucro():

    url = "https://docs.google.com/spreadsheets/d/1_sDZ3s3VEzM8abyn-iUItwNGIOPJJRQxfV_hIAQZODc/export?format=csv&gid=1503634502"

    df = pd.read_csv(url)

    lucro = df.iloc[-1][["LUCRO DIARIO"]].item()

    return lucro


def import_data():

    url = "https://docs.google.com/spreadsheets/d/1_sDZ3s3VEzM8abyn-iUItwNGIOPJJRQxfV_hIAQZODc/export?format=csv&gid=1503634502"

    df = pd.read_csv(url)

    data_lucro = df.iloc[-1][["DATA LUCRO"]].item()

    return data_lucro

