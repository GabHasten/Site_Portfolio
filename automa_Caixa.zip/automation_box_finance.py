from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from import_dados import import_lucro,import_data
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC




senha_site = "6e17i3mk7"
email_site = "contatothgrafica@gmail.com"


driver = webdriver.Chrome()
driver.get("https://www.thgrafica.com.br/admin/login.php")

driver.maximize_window()

email = driver.find_element(By.XPATH,"//*[@id='form-logar']/div[1]/div/label/input")
email.clear()
email.send_keys(email_site)

time.sleep(2)

senha = driver.find_element(By.XPATH,"//*[@id='form-logar']/div[2]/div/label/input")
senha.clear()
senha.send_keys(senha_site)

driver.find_element(By.XPATH,"//*[@id='form-logar']/div[3]/div[1]/button").click()

time.sleep(5)

driver.find_element(By.XPATH,"//*[@id='conteudo-geral']/div[2]/div/div[1]/div/div[3]/a[3]").click()

driver.find_element(By.ID, "select2-PedidoListaClientes-container").click()

# 2. Espera o campo de busca aparecer
search_box = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.CLASS_NAME, "select2-search__field"))
)

# 3. Digita o nome
search_box.send_keys("thi")

# 4. Espera a opção aparecer
option = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, "//li[contains(text(),'thiago santos')]"))
)

# 5. Clica na opção
option.click()



driver.find_element(By.XPATH,"//*[@id='primeiroPasso']/div/div/div[2]/div/div[3]/span").click()

valor = driver.find_element(By.XPATH,"//*[@id='modal-pedido-novo-item-descrito']/div/form/div[2]/div[2]/div/div/div/div[1]/div[4]/label/div/input")
valor.clear()
valor.send_keys(import_lucro())

driver.find_element(By.XPATH,"//*[@id='modal-pedido-novo-item-descrito']/div/form/div[2]/div[2]/div/div/div/div[1]/div[1]/label/input").send_keys(import_data())

driver.find_element(By.XPATH,"//*[@id='modal-pedido-novo-item-descrito']/div/form/div[3]/button").click()

select_element = driver.find_element(By.NAME, "frete[retirada]")
driver.execute_script("""
    arguments[0].value = '1';
    arguments[0].dispatchEvent(new Event('change'));
    arguments[0].dispatchEvent(new Event('chosen:updated'));
""", select_element)

driver.find_element(By.XPATH,"//*[@id='segundoPasso']/div/div[2]/div[1]/div[5]/div/button").click()
